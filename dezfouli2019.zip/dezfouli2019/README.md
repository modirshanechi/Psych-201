### REFERENCE
Dezfouli A, Griffiths K, Ramos F, Dayan P, Balleine BW (2019) Models that learn how humans learn: The case of decision-making and its disorders. PLOS Computational Biology 15(6): e1006903. https://doi.org/10.1371/journal.pcbi.1006903

### Data source:
https://github.com/adezfouli/rnn_beh.git

