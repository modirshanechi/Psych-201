import sys
import jsonlines
import pandas as pd
from tqdm import tqdm

sys.path.append("..")

json_out = []
CHARACTER_LIMIT = 120000

df = pd.read_csv("exp3.csv")

# add the general task instructions
task_instructions = (
    "Thank you for participating in this experiment!\n"
    "The experiment begins with two practice trials followed by 24 trials of the same main task.\n"
    "In each trial, you will see a display with a mix of black and red circles.\n"
    "Your task is to estimate what percentage of the total circles are red.\n"
    "You will use a slider to indicate your estimate. The slider starts at 50%, but you can adjust it both ways.\n"
    "Try to be as accurate as possible.\n\n"
)

# add every trial instructions
instructions_trial = (
    "What percentage of the circles are red? You see {red} red circles among 432 circles in total.\n"
    "Your estimate: {response}.\n"
)

for participant in tqdm(df.submission_id.unique()):
    # create a future json entry for the participant
    par_dict = {"text": task_instructions, "experiment": 'vantiel2020-probabilistic_pragrmatics/exp3.csv',
                "participant": str(participant)}
    # reindex and drop the old index
    par_df = df[df.submission_id == participant].reset_index(drop=True)
    # iterate over trials, construct interpretation and production instructions
    for _, trial in par_df.iterrows():
        # retrieve the key corresponding to the provided response and number of red circles by retrieving the
        # indices in the list
        response = int(trial["rating_slider"] / 4.32)
        red = trial["dots_number"]

        # fill the parameters to the trial outputs
        trial_instruction = instructions_trial.format(
            response=f"<<{response}%>>",
            red=red
        )

        # append trial prompt to participant's recording
        par_dict["text"] += trial_instruction + "\n"

    # check that the prompt is not too long
    assert (
            len(par_dict["text"]) < CHARACTER_LIMIT
    ), f"Participant {participant} has too many characters: ({len(par_dict['text'])})"

    json_out.append(par_dict)

with jsonlines.open("exp3.jsonl", "w") as writer:
    writer.write_all(json_out)
