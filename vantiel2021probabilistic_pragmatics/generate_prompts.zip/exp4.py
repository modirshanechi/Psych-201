import sys
import jsonlines
import pandas as pd
from tqdm import tqdm

sys.path.append("..")

# Set the character limit for JSON output
CHARACTER_LIMIT = 32000

# Load the dataset for Experiment 4
df = pd.read_csv("exp4.csv")

# Set of quantifiers that should not include "of the"
our_set = {"Few", "Very few", "Hardly any", "Many", "Some", "A few", "Several"}

# General task instructions
task_instructions = (
    "Thank you for participating in the experiment!\n\n"
    "In this study, you will be presented with a series of trials.\n"
    "In each trial, you will see a display of red and black circles, \n"
    "along with a statement about the distribution of colors (e.g., 'Half of the circles are black').\n"
    "Your task is to evaluate how well the statement describes the display \n "
    "by adjusting a slider ranging from 0 to 100.\n\n"
)

# Instructions for each trial
instructions_trial = (
    "You see {dots} red circles among 432 circles in total.\n"
    "How well does this statement describe the display?\n"
    "Statement: \"{formatted_quantifier} circles are red.\"\n"
    "Your rating: {response}\n\n"
)

json_out = []

# Iterate over participants
for participant in tqdm(df['subject'].unique()):
    # Create a JSON entry for each participant
    par_dict = {"text": task_instructions, "experiment": 'exp4.csv', "participant": str(participant)}

    # Filter data for the current participant
    par_df = df[df['subject'] == participant].reset_index(drop=True)

    # Iterate over trials for this participant
    for _, trial in par_df.iterrows():
        quantifier = trial["quantifier"]
        dots = trial["dots"]
        response = trial["dep"]

        # Adjust quantifier format based on the defined set
        if quantifier not in our_set:
            quantifier = f"{quantifier} of the"
        formatted_quantifier = quantifier

        # Format trial instruction
        trial_instruction = instructions_trial.format(
            dots=dots,
            formatted_quantifier=formatted_quantifier,
            response=f"<<{response}>>"
        )

        # Append trial data to participant's record
        par_dict["text"] += trial_instruction

    # Ensure character limit is not exceeded
    assert (
            len(par_dict["text"]) < CHARACTER_LIMIT
    ), f"Participant {participant} has too many characters: ({len(par_dict['text'])})"

    json_out.append(par_dict)

# Save output to JSONL file
with jsonlines.open("exp4.jsonl", "w") as writer:
    writer.write_all(json_out)