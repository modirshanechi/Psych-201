import sys
import jsonlines
import pandas as pd
from tqdm import tqdm
sys.path.append("..")

json_out = []
CHARACTER_LIMIT = 32000

df = pd.read_csv("exp1a.csv")

# general task instructions
task_instructions = (
    "Thank you for participating in this experiment!\n"
    "There will be 10 displays of the same task.\n"
    "In each task trial you will read a short description of a task and will be asked to answer a question by typing a response.\n"
    "After seeing a certain amount of black and red circles on the screen, you will be asked to complete a sentence of the form “— are red”\n\n"
    "Please, do NOT write numbers or number words!\n\n"
)

#every trial instruction
instructions_trial= (
    "You see {red} red circles among 432 circles in total. How many of the circles are red? Please complete a sentence of form “— are red”\n"
    "Your answer: {response} are red.\n"
)

#go over participants
for participant in tqdm(df.SUBJECT.unique()):
    # create a future json entry for the participant
    par_dict = {"text": task_instructions, "experiment": 'vantiel2020probabilistic_pragmatics/exp1a.csv', "participant": str(participant)}
    #reindex and drop the old index
    par_df = df[df.SUBJECT == participant].reset_index(drop=True)
    # iterate over trials, construct interpretation and production instructions
    for _, trial in par_df.iterrows():
        # retrieve the key corresponding to the provided response and number of the red circles by retrieving the indices in the list
        response = trial["RESP"]
        red = trial["DOTS"]

        #fill the parameters to the trial outputs
        trial_instuction = instructions_trial.format(
            red=red,
            response=f"<<{response}>>"
        )

        # append trial prompt to participant's recording
        par_dict["text"] += trial_instuction + "\n"

    # check that the prompt is not too long
    assert (
        len(par_dict["text"]) < CHARACTER_LIMIT
    ), f"Participant {participant} has too many characters: ({len(par_dict['text'])})"

    json_out.append(par_dict)

#write to the jsonl file
with jsonlines.open("exp1a.jsonl", "w") as writer:
    writer.write_all(json_out)
