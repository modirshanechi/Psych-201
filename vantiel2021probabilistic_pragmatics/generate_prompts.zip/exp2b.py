import sys
import jsonlines
import pandas as pd
from tqdm import tqdm

sys.path.append("..")

json_out = []
CHARACTER_LIMIT = 32000

#set of the quantifiers without "of the" part
our_set={"few", "very few", "hardly any", "many", "some", "a few", "several"}


# dictionary for the pairs of predicates
dictionary = {
    "are from California": "are from San Francisco",
    "saw an insect": "saw a cockroach",
    "read a novel": "read 'Moby Dick'",
    "saw a bird": "saw an eagle",
    "played a card game": "played poker",
    "used a herb": "used rosemary",
    "are from Texas": "are from Houston",
    "ordered fish": "ordered salmon",
    "ordered meat": "ordered steak",
    "ate a fruit": "ate an apple",
    "drank alcohol": "drank wine",
    "bought a flower": "bought a rose",
    "own a pet": "own a dog",
    "own a vehicle": "own a truck",
    "own a weapon": "own a sword",
    "saw an animal": "saw a lion",
    "travelled to Japan": "travelled to Tokyo",
    "ate vegetables": "ate carrots",
    "bought a gemstone": "bought a diamond",
    "were drinking a soda": "were drinking a Pepsi",
    "watched a movie": "watched 'Pulp Fiction'",
    "saw a tree": "saw an oak",
    "travelled to Russia": "travelled to Moscow",
    "travelled to France": "travelled to Paris",
    "are from Illinois": "are from Chicago"
}

# read a file
df = pd.read_csv("exp2b.csv", delimiter=' ')

# general task instructions
task_instructions = (
    "Thank you for participating in this experiment!\n"
    "There will be 34 trials of the same task.\n"
    "In each trial, you will read a statement (premise) and a possible conclusion.\n"
    "Your task is to decide whether the premise implies the conclusion.\n"
    "Please select ‘1' on the keyboard if the conclusion is true based on the statement or ‘0' if it does not necessarily follow.\n"
    "For example: ¨All guests ate salmon.¨ implies that ¨All guests ate fish.¨ since salmon is a type fish.\n"
    "But at the same time: ¨All guests ate fish.¨ doesn't imply ¨All guests ate salmon.¨ since not all fish is salmon.\n\n"
)

# every trial instruction
instructions_trial = (
    "Please indicate whether the premise ¨{quantifier} people {premise}¨ implies the conclusion ¨{quantifier} people {conclusion}¨. Please type 1 for Yes and 0 for No.\n"
    "Your answer: {response}\n"
)
# go over participants
for participant in tqdm(df.subject.unique()):
    # create a future json entry for the participant
    par_dict = {"text": task_instructions, "experiment": 'vantiel2020probabilistic_pragmatics/exp2b.csv',
                "participant": str(participant)}
    RT = []
    # reindex and drop the old index
    par_df = df[df.subject == participant].reset_index(drop=True)
    # iterate over trials, construct interpretation and production instructions
    for _, trial in par_df.iterrows():
        # retrieve the keys corresponding to the provided response, trial type, predicate, quantifier and reaction type
        response = trial["response"]
        type = trial["type"]
        pred = trial["predicate"]
        quantifier = trial["quantifier"]
        RT.append(trial["rt"])

        #quantifier adjustment
        if quantifier not in our_set:
            quantifier += " of the"
        quantifier = quantifier.capitalize()

        # align premise and conclusion with respond to the type, retrieving the strong statement from the dictionary
        if type == "strong_to_weak":
            premise = dictionary[pred]
            conclusion = pred
        else:
            conclusion = dictionary[pred]
            premise = pred

        # fill the parameters to the trial outputs
        trial_instuction = instructions_trial.format(
            premise=premise,
            quantifier = quantifier,
            conclusion=conclusion,
            response=f"<<{response}>>"
        )

        # append trial prompt to participant's recording
        par_dict["text"] += trial_instuction + "\n"

    # check that the prompt is not too long
    assert (
            len(par_dict["text"]) < CHARACTER_LIMIT
    ), f"Participant {participant} has too many characters: ({len(par_dict['text'])})"

    # append reaction times
    par_dict["RTs"] = RT

    json_out.append(par_dict)

# write to the jsonl file
with jsonlines.open("exp2b.jsonl", "w") as writer:
    writer.write_all(json_out)



